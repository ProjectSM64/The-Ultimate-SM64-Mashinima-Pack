If you have Rice Video, then put the Final Destination Folder with the larger textures
in your folder path, ex. C:\Program Files (x86)\Project64 1.6\Plugin\hires_texture\SUPER MARIO 64
Please credit me for using the level in a video/hack/mod.