RICE2JABO for SM64 Eyes by GlitchyPSIX

___
Drop this .bat in a folder where there are 3 SM64 eye textures with the Rice
texture filenames, then open it to transform them into Jabo texture filenames.

<<<--->>>
JABO2RICE for SM64 Eyes by GlitchyPSIX


___
Works pretty much the same as Rice2Jabo.bat, just that the files required must
be in the Jabo texture format.
(Only works for the eyes as of now.)