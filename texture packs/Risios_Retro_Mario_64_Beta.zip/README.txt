Thanks for downloading the pack!

Special thanks to Dungeon O, La Bertha Network, Xavya, Asian Dave, and all the great folks at Emutalk.

Contact me at:

AIM: Bowlofmikeyos

Xbox Live: LBNRisio

